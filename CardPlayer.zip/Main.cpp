/*
Justin McDonald
Lab6in
Write a program that
*/

#include <iostream>
#include "graph1.h"
#include "CardPlayer.h"
#include <ctime>

using namespace std;

int main()
{
	//Variable Declaration/Initialization
	int noCards = 0;
	char color = 'r';
	int x = 150;
	int y = 100;
	CardPlayer player1;
	CardPlayer dealer;
	char repeat = 'y';

	//Display Graphics
	displayGraphics();

	do {
	srand(time(0));

	//Prompt for the suit color
	cout << "Enter the suit color (r for red suits, b for black suits): ";
	cin >> color;

	//Set the color
	
		if (color == 'r')
		{
			player1.setColor(color);
			dealer.setColor('b');
		}
		else if (color == 'b')
		{
			player1.setColor(color);
			dealer.setColor('r');
		}

	//Prompt for the number of cards
	cout << "Enter the number of cards to deal to each player (>= 5 but <= 10): ";
	cin >> noCards;

	//Set the nuCards
	player1.setNoCards(noCards);
	dealer.setNoCards(noCards);

	//Deal the cards
	for (int i = 0; i < (noCards); i++)
	{
		if (i % 2 == 0)
		{
			player1.deal();
		}
		else
		{
			dealer.deal();
		}
	}
	
	

	//Display the cards
	player1.displayHand(x, y);
	dealer.displayHand(x+100, y);

	//Display the score
	player1.computeScore();
	dealer.computeScore();
	gout << setPos(x, 400) << "score 1: " << player1.computeScore() << endg;
	gout << setPos(x+100, 400) << "score 2: " << dealer.computeScore() << endg;

} while ((repeat == 'y') || (repeat == 'Y'));

	return 0;

}
