#include "RightTriangle.h"
#include <iostream>
#include "graph1.h"
#include <cmath>

RightTriangle::RightTriangle()
{
	this->a.setPoint(0, 0);
	this->b.setPoint(0, 0);
	this->c.setPoint(0, 0);

}

RightTriangle::RightTriangle(GenPoint vertex, int height, int base, Color color)
{
	
	this->a = vertex;
	this->b.setPoint(a.getX(), (a.getY() - height));
	this->c.setPoint(a.getX() + base, a.getY());
	this->color.setColor(color.getRed(), color.getGreen(), color.getBlue());

}

void RightTriangle::print()
{
	gout << setPos(0, 15) << "Right Triangle" << endg;
	gout << setPos(200, 420) << "Point a: (" << a.getX() << "," << a.getY() << ")" << endg;
	gout << setPos(200, 435) << "Point b: (" << b.getX() << "," << b.getY() << ")" << endg;
	gout << setPos(200, 450) << "Point c: (" << c.getX() << "," << c.getY() << ")" << endg;
	gout << setPos(200, 465) << "Perimeter: " << getPerimeter() << " Area: " << getArea() << endg;
	gout << setPos(0, 400) << "----------------------------------------------------------------------------------------" << endg;

}
