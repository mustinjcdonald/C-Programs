#include <iostream>
#include <cmath>
#include "Quadrilateral.h" 
#include "graph1.h"


Quadrilateral::Quadrilateral()
{
	a.setPoint(0, 0);
	b.setPoint(0, 0);
	c.setPoint(0, 0);
	d.setPoint(0, 0);
	color.setColor(0, 0, 0);
}
Quadrilateral::Quadrilateral(GenPoint a, GenPoint b, GenPoint c, GenPoint d, Color color)
{
	this->a.setPoint(a.getX(), a.getY());
	this->b.setPoint(b.getX(), b.getY());
	this->c.setPoint(c.getX(), c.getY());
	this->d.setPoint(d.getX(), d.getY());
	this->color.setColor(color.getRed(), color.getGreen(), color.getBlue());
}
void Quadrilateral::setPoints(GenPoint a, GenPoint b, GenPoint c, GenPoint d)
{
	this->a.setPoint(a.getX(), a.getY());
	this->b.setPoint(b.getX(), b.getY());
	this->c.setPoint(c.getX(), c.getY());
	this->d.setPoint(d.getX(), d.getY());
}

double Quadrilateral::getPerimeter()
{
	double side1 = sqrt(pow(a.getX() - b.getX(), 2.0) + pow(a.getY() - b.getY(), 2.0));
	double side2 = sqrt(pow(b.getX() - c.getX(), 2.0) + pow(b.getY() - c.getY(), 2.0));
	double side3 = sqrt(pow(d.getX() - c.getX(), 2.0) + pow(d.getY() - c.getY(), 2.0));
	double side4 = sqrt(pow(a.getX() - d.getX(), 2.0) + pow(a.getY() - d.getY(), 2.0));

	return(side1 + side2 + side3 + side4);

}
void Quadrilateral::print()
{
	//display points and perimeter
	gout << setPos(200, 420) << "Point a: (" << a.getX() << "," << a.getY() << ")" << endg;
	gout << setPos(200, 435) << "Point b: (" << b.getX() << "," << b.getY() << ")" << endg;
	gout << setPos(200, 450) << "Point c: (" << c.getX() << "," << c.getY() << ")" << endg;
	gout << setPos(200, 465) << "Point d: (" << d.getX() << "," << d.getY() << ")" << endg;
	gout << setPos(200, 480) << "Perimeter: " << getPerimeter() << endg;
	gout << setPos(0, 400) << "----------------------------------------------------------------------------------------" << endg;

}
void Quadrilateral::draw()
{
	int obj = 0;
	obj = drawLine(a.getX(), a.getY(), b.getX(), b.getY(), 2);
	::setColor(obj, color.getRed(), color.getGreen(), color.getBlue());

	obj = drawLine(b.getX(), b.getY(), c.getX(), c.getY(), 2);
	::setColor(obj, color.getRed(), color.getGreen(), color.getBlue());

	obj = drawLine(c.getX(), c.getY(), d.getX(), d.getY(), 2);
	::setColor(obj, color.getRed(), color.getGreen(), color.getBlue());

	obj = drawLine(d.getX(), d.getY(), a.getX(), a.getY(), 2);
	::setColor(obj, color.getRed(), color.getGreen(), color.getBlue());
}