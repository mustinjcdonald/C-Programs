#include <iostream>
#include <cmath>
#include "GenRectangle.h" 
#include "graph1.h"





GenRectangle::GenRectangle()
{
	this->a.setPoint(0, 0);
	this->b.setPoint(0, 0);
	this->c.setPoint(0, 0);
	this->d.setPoint(0, 0);

}
GenRectangle::GenRectangle(GenPoint ul, GenPoint lr, Color c)
{
	this->a.setPoint(ul.getX(), ul.getY());
	this->c.setPoint(lr.getX(), lr.getY());
	this->b.setPoint(lr.getX(), ul.getY());
	this->d.setPoint(ul.getX(), lr.getY());

	this->color.setColor(c.getRed(), c.getGreen(), c.getBlue());

}

void GenRectangle::setPoints(GenPoint ul, GenPoint lr)
{
	GenPoint b(lr.getX(), ul.getY());
	GenPoint d(ul.getX(), lr.getY());
	Quadrilateral::setPoints(ul, b, lr, d);
}
double GenRectangle::getArea()
{
	double area;
	double length;
	double width;
	length = sqrt(pow(a.getX() - b.getX(), 2.0) + pow(a.getY() - b.getY(), 2.0));
	width = sqrt(pow(a.getX() - d.getX(), 2.0) + pow(a.getY() - d.getY(), 2.0));
	area = length * width;

	return(area);

}
void GenRectangle::print()
{
	Quadrilateral::print();
	gout << setPos(200, 405) << "Shape info Follows for: Rectangle" << endg;
	gout << setPos(0, 15) << "Rectangle Information " << endg;
	gout << setPos(0, 30) << "Area: " << getArea() << endg;
	gout << setPos(0, 300) << "---------------------------------------------------------------------------------";
	Quadrilateral::draw();


}