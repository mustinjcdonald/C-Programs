#include <iostream>
#include "graph1.h"
#include "Trapezoid.h"
#include "Quadrilateral.h"
#include "Shape.h"
#include "Color.h"
#include <cmath>

Trapezoid::Trapezoid()
{
	this->a.setPoint(0, 0);
	this->b.setPoint(0, 0);
	this->c.setPoint(0, 0);
	this->d.setPoint(0, 0);
}

Trapezoid::Trapezoid(GenPoint a, GenPoint b, GenPoint c, GenPoint d, Color color)
{
	this->a.setPoint(a.getX(), a.getY());
	this->b.setPoint(b.getX(), b.getY());
	this->c.setPoint(c.getX(), c.getY());
	this->d.setPoint(d.getX(), d.getY());
	this->color.setColor(color.getRed(), color.getGreen(), color.getBlue());

}

void Trapezoid::setPoints(GenPoint a, GenPoint b, GenPoint c, GenPoint d)
{
	this->a.setPoint(a.getX(), a.getY());
	this->b.setPoint(b.getX(), b.getY());
	this->c.setPoint(c.getX(), c.getY());
	this->d.setPoint(d.getX(), d.getY());
}

double Trapezoid::getArea()
{
	double  area;
	double base1;
	double base2;
	double height;

	height = sqrt(pow(b.getX() - c.getX(), 2.0) + pow(b.getY() - c.getY(), 2.0));
	base1 = sqrt(pow(a.getX() - b.getX(), 2.0) + pow(a.getY() - b.getY(), 2.0));
	base2 = sqrt(pow(d.getX() - c.getX(), 2.0) + pow(d.getY() - c.getY(), 2.0));

	area = (0.5*(base1 + base2) * height);

	return area;

}

void Trapezoid::print()
{
	gout << setPos(10, 10) << "Trapezoid Information" << endg;
	gout << setPos(10, 25) << "Area: " << getArea() << endg;
	gout << setPos(200, 420) << "Point a: (" << a.getX() << "," << a.getY() << ")" << endg;
	gout << setPos(200, 435) << "Point b: (" << b.getX() << "," << b.getY() << ")" << endg;
	gout << setPos(200, 450) << "Point c: (" << c.getX() << "," << c.getY() << ")" << endg;
	gout << setPos(200, 465) << "Point d: (" << d.getX() << "," << d.getY() << ")" << endg;
	gout << setPos(200, 480) << "Perimeter: " << getPerimeter() << endg;
	gout << setPos(0, 400) << "----------------------------------------------------------------------------------------" << endg;
	Quadrilateral::draw();
}
