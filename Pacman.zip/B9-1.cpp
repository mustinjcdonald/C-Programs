/*
// Justin McDonald
// B9-1
// Write a program that moves object pac.bmp accordingly to the inputed amount of rows & columns.
*/

#include <iostream>
#include <ctime>
#include "graph1.h"

using namespace std;

int main()
{

	int x1 = 0;
	int y1 = 0;
	int i = 0;
	int j = 0;
	int rows = 0;
	int cols = 0;
	int speed = 0;
	int pac_obj = 0;
	int start_time = 0, curr_time = 0, total_time = 0;
	char repeat = 'y';

	displayGraphics();

	do
	{

		cout << "Enter the # of rows to display (> 0 but < 640): ";
		cin >> rows;
	} while (rows < 0 || rows > 640);


	do
	{
		cout << "Enter the # of cols to display (> 0 but < 640): ";
		cin >> cols;
	} while (cols < 0 || cols > 640);

	speed = 1;

	pac_obj = displayBMP("pac.bmp", x1, y1);

	start_time = time(0);

	for (i = 0; i < rows; i++)
	{
		x1 = rows;
		for (j = 0; j < cols; j++)
		{
			y1 = cols;
			while (x1 > i)
			{
				i++;

				moveObject(pac_obj, i, j);
				Sleep(10);
			}

			while (y1 > j)
			{
				j++;

				moveObject(pac_obj, i, j);
				Sleep(10);
			}

			curr_time = time(0);
			total_time = (curr_time - start_time);

			gout << setPos(200, 400) << "Pacman traveled " << rows << " rows and " << cols <<
				" columns in " << total_time << " seconds." << endg;


			cout << "Run program again? (y/n): ";
			cin >> repeat;


			clearGraphics();

		} while ((repeat == 'y') || (repeat == 'Y'));


		return 0;
	}

}