#ifndef SHAPE_H
#define SHAPE_H

#include "GenPoint.h"
#include "Color.h"

class Shape
{
protected:
	Color color;  

public:
	Shape();  
	Color getColor(); 
	void setColor(Color color);
	virtual double getPerimeter()=0;
	virtual void print()=0;
	virtual void draw()=0;

};

#endif
