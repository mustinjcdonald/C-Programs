#include <iostream>
#include "Shape.h"
#include "graph1.h"

Shape::Shape() 
{
	color.setColor(0, 0, 0);

}

Color Shape::getColor()  
{
	return color;

}
void Shape::setColor(Color color)  
{
	color.setColor(color.getRed(), color.getGreen(), color.getBlue());

}
