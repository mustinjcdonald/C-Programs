#include <iostream>
#include "triangle.h"
#include "graph1.h"
#include <cmath>

Triangle::Triangle()
{
	this->a.setPoint(0, 0);
	this->b.setPoint(0, 0);
	this->c.setPoint(0, 0);

}

Triangle::Triangle(GenPoint a, GenPoint b, GenPoint c, Color color)
{
	this->a.setPoint(a.getX(), a.getY());
	this->b.setPoint(b.getX(), b.getY());
	this->c.setPoint(c.getX(), c.getY());
	this->color.setColor(color.getRed(), color.getGreen(), color.getBlue());

}

void Triangle::setPoints(GenPoint a, GenPoint b, GenPoint c)
{
	this->a.setPoint(a.getX(), a.getY());
	this->b.setPoint(b.getX(), b.getY());
	this->c.setPoint(c.getX(), c.getY());

}

double Triangle::getArea()
{
	double side1 = sqrt(pow(a.getX() - b.getX(), 2.0) + pow(a.getY() - b.getY(), 2.0));
	double side2 = sqrt(pow(b.getX() - c.getX(), 2.0) + pow(b.getY() - c.getY(), 2.0));
	double side3 = sqrt(pow(a.getX() - c.getX(), 2.0) + pow(a.getY() - c.getY(), 2.0));
	double s = (side1 + side2 + side3) / 2.0;
	double area = sqrt(s*(s - side1)*(s - side2)*(s - side3));

	return area;
}

double Triangle::getPerimeter()
{
	double side1 = sqrt(pow(a.getX() - b.getX(), 2.0) + pow(a.getY() - b.getY(), 2.0));
	double side2 = sqrt(pow(b.getX() - c.getX(), 2.0) + pow(b.getY() - c.getY(), 2.0));
	double side3 = sqrt(pow(a.getX() - c.getX(), 2.0) + pow(a.getY() - c.getY(), 2.0));
	double perimeter = 0;

	perimeter = (side1 + side2 + side3);

	return perimeter;

}

void Triangle::print()
{
	gout << setPos(0, 15) << "Triangle" << endg;
	gout << setPos(200, 420) << "Point a: (" << a.getX() << "," << a.getY() << ")" << endg;
	gout << setPos(200, 435) << "Point b: (" << b.getX() << "," << b.getY() << ")" << endg;
	gout << setPos(200, 450) << "Point c: (" << c.getX() << "," << c.getY() << ")" << endg;
	gout << setPos(200, 465) << "Perimeter: " << getPerimeter() << " Area: " << getArea() << endg;
	gout << setPos(0, 400) << "----------------------------------------------------------------------------------------" << endg;

}

void Triangle::draw()
{
	int L1;
	int L2;
	int L3;

	
	L1 = drawLine(a.getX(), a.getY(), b.getX(), b.getY(), 1);
	::setColor(L1, color.getRed(), color.getGreen(), color.getBlue());

	L2 = drawLine(c.getX(), c.getY(), b.getX(), b.getY(), 1);
	::setColor(L2, color.getRed(), color.getGreen(), color.getBlue());

	L3 = drawLine(a.getX(), a.getY(), c.getX(), c.getY(), 1);
	::setColor(L3, color.getRed(), color.getGreen(), color.getBlue());

}
