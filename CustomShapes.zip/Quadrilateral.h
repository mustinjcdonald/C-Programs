#ifndef QUADRILATERAL_H
#define QUADRILATERAL_H

#include "GenPoint.h"
#include "Color.h"
#include "Shape.h"

class Quadrilateral : public Shape
{
protected:

	GenPoint a;
	GenPoint b;
	GenPoint c;
	GenPoint d;
	

public:
	Quadrilateral(); //Sets all points/colors to 0
	Quadrilateral(GenPoint a, GenPoint b, GenPoint c, GenPoint d, Color color);
	void setPoints(GenPoint a, GenPoint b, GenPoint c, GenPoint d);
	double getPerimeter();
	virtual void print();
	virtual void draw();
};

#endif