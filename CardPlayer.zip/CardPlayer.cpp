#include <iostream>
#include <ctime>
#include "graph1.h"
#include "CardPlayer.h"

CardPlayer::CardPlayer()
{
	color = 'r';
	noCards = 0;
	hand = NULL;
}

CardPlayer::~CardPlayer()
{
	delete[] hand;
}

void CardPlayer::setNoCards(int noCards)
{
	if (noCards < 5)
	{
		this->noCards = 5;
	}
	else if (noCards > 10)
	{
		this->noCards = 10;
	}
	else
	{
		this->noCards = noCards;
	}
	//Cleanup hand
	delete[] hand;
	hand = new int[this->noCards];

}

int CardPlayer::getNoCards()
{
	return noCards;
}

void CardPlayer::setColor(char color)
{
	this->color = color;
}

void CardPlayer::displayHand(int x, int y)
{

	gout << setPos(150, 90) << "Player 1" << endg;
	gout << setPos(250, 90) << "Dealer" << endg;

	int i = 0;
	char fn[10];

	if (color == 'r')
	{
		for (i = 0; i < noCards; i++)
		{
			sprintf_s(fn, "d%d.bmp", hand[i]);
			displayBMP(fn, x, y);
			y += 20;

		}
		
	}

	else 
	{
		for (i = 0; i < noCards; i++)
		{
			sprintf_s(fn, "c%d.bmp", hand[i]);
			displayBMP(fn, x, y);
			y += 20;
		}
	}

}
int CardPlayer::computeScore()
{
	int i = 0;
	int score = 0;
	for (i = 0; i < noCards; i++)
	{
		if (hand[i] >= 2 && hand[i] <= 10)
		{
			score += hand[i];
		}
		else if (hand[i] >= 11 && hand[i] <= 13)
		{
			score += 10;
		}
		else
			score += 11;
	}


	return score;
}

void CardPlayer::deal()
{
	int i = 0;
	int j = 0;
	bool duplicate = false;
	for (i = 0; i < noCards; i++)
	{
		hand[i] = rand() % 13 + 2;
		do
		{
			duplicate = false;
			for (j = 0; j < i; j++)
			{
				if (hand[i] == hand[j])
				{
					hand[i] = rand() % 13 + 2;
					duplicate = true;
					break;
				}
			}
		} while (duplicate == true);
	}
}