#include <iostream>
#include "graph1.h"
#include "Color.h"
#include <cmath>

using namespace std;


Color::Color() 
{
	setColor(0, 0, 0);
}

Color::Color(int r, int g, int b) 
{
	r = 0;
	g = 0;
	b = 0;
}

void Color::setColor(int r, int g, int b) 
{
	if (r < 0) 
		r = 0;
	if (r > 255)
		r = 255;

	this->r = r;

	if (g < 0)
		g = 0;
	if (g > 255)
		g = 255;
	this->g = g;

	if (b < 0) 
		b = 0;
	if (b > 255)
		b = 255;
	this->b = b;
}

int Color::getRed() 
{
	return r;
}

int Color::getGreen()
{
	return g;
}

int Color::getBlue()
{
	return b;
}

Color Color::operator+(Color right)
{
	Color result;

	result.r = (r + right.r);

	if (result.r >= 255) 
	{
		result.r = 255;
	}

	result.g = (g + right.g);
	
	if (result.g >= 255)
	{
		result.g = 255;
	}

	result.b = (b + right.b);
	
	if (result.b >= 255) 
	{
		result.b = 255;
	}

	return(result);
}

Color Color::operator-(Color right)
{
	Color result;

	
	result.r = (r - right.r);
	
	if (result.r < 0)
		result.r = 0;

	
	result.g = (g - right.g);
	
	if (result.g < 0)
		result.g = 0;

	
	result.b = (b - right.b);
	
	if (result.b < 0)
		result.b = 0;


	return(result);
}

Color Color::operator*(int right)
{
	Color result;

	result.r = (r * right); 
	result.g = (g * right);
	result.b = (b * right);


	return(result);

}

Color Color::operator/(int right)
{
	Color result;

	result.r = (r / right); 
	result.g = (g / right);
	result.b = (b / right);


	return(result);

}
bool Color::operator==(Color right) 
{
	if (r == right.r && g == right.g && b == right.b) 
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Color::operator!=(Color right) 
{
	if (r != right.r) 
	{
		return true;
	}

	if (g != right.g)
	{
		return true;
	}

	if (b != right.b)
	{
		return true;
	}

	else
		return false;
}

void Color::operator=(Color right)
{
	this->r = right.r;
	this->g = right.g;
	this->b = right.b;
}

Color Color::operator!() 
{
	Color result;

	result.r = 255 - r;
	result.g = 255 - g;
	result.b = 255 - b;

	return result;
}


Color Color::operator++() 
{


	Color c1;
	Color result1;

	r += 25;
	g += 25;
	b += 25;
	c1.setColor(r, g, b);



	return(*this);

}

Color Color::operator++(int dummy)
{

	Color first = *this;
	Color c1;
	Color result1;
	
	r += 25;
	g += 25;
	b += 25;
	c1.setColor(r, g, b);

	return(first);

}

Color Color::operator--() 
{

	Color c1;
	Color result1;

	r -= 25;
	g -= 25;
	b -= 25;
	c1.setColor(r, g, b);



	return(*this);
}

Color Color::operator--(int dummy)
{
	Color orig = *this;
	Color c1;
	Color result1;
	
	r -= 25;
	g -= 25;
	b -= 25;
	c1.setColor(r, g, b);



	return(orig);
}

bool Color::operator>(Color right) 
{
	//bool result3;
	Color c1;
	Color c2;
	double color1;
	double color2;

	//c1.setColor(r,g,b);
	color1 = sqrt(double((getRed()) ^ 2 + (getGreen()) ^ 2 + (getBlue()) ^ 2));

	//c2.setColor(r,g,b);
	color2 = sqrt(double((right.getRed()) ^ 2 + (right.getGreen()) ^ 2 + (right.getBlue()) ^ 2));


	if (color1 > color2)
		return true;
	else
		return false;
}


bool Color::operator<(Color right) 
{
	Color c1;
	Color c2;
	double color1;
	double  color2;
	//c1.setColor(r,g,b);

	color1 = sqrt(double((getRed()) ^ 2 + (getGreen()) ^ 2 + (getBlue()) ^ 2));

	//c2.setColor(r,g,b);
	color2 = sqrt(double((right.getRed()) ^ 2 + (right.getGreen()) ^ 2 + (right.getBlue()) ^ 2));

	if (color1 < color2)
		return true;
	else
		return false;

}



void Color::draw(int x, int y, int w, int h) 
{
	int rect_obj;

	rect_obj = drawRect(x, y, w, h);
	::setColor(rect_obj, r, g, b);
}
